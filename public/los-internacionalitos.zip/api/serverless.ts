import app from '../server/app';

export default function handler(req: any, res: any) {
  if (req && req.url && !req.url.startsWith('/api')) {
    req.url = '/api' + (req.url.startsWith('/') ? req.url : '/' + req.url);
  }
  return app(req, res);
}
